﻿namespace ExamenNicIan.Models
{
    public class MapModel
    {
        public string MapId { get;  }

        public MapModel(string mapId)
        {
            MapId = mapId;
        }
    }
}
